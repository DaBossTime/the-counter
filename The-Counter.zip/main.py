#Importing Stuff
import time, os, random

def count():
  #Asking the Variables
  end = input('What number do you want the Counter to count to?\n> ')
  speed = input('\nHow fast do you want the Counter to count for you?(in seconds)\n> ')
  #Converting the Variables to Integers(and checking if the user actually entered a number)
  try:
    end = int(end)
    speed = float(speed)
  except ValueError:
    print('\nUh oh! Looks like you entered a letter or special character instead of a number! Please try entering a number again.(or you entered a incorrect decimal [example: 0.001])')
    time.sleep(6)
    os.system('clear')
    count()
  #Setting some other Variables
  numb = 0
  os.system('clear')
  #The Loop that actually counts
  while numb < end:
    print('The Counter has counted to -',numb)
    time.sleep(speed)
    os.system('clear')
    numb = numb + 1
  #Showing that the Counting is complete
  print('The Counter has counted to -',numb)
  print('Counting Complete!')
  time.sleep(1.5)
  #Asking if the Counter should count again.
  again = input('\nAgain?\n[Yes(y)|No(n)]\n> ')
  if again == 'y':
    os.system('clear')
    count()
  elif again == 'n':
    print('\nBye Bye!')
  else:
    #Choosing a Random choice if it should take it as a yes or no.
    rand = random.randint(1, 2)
    if rand == 1:
      print("\nI'll take that as a yes.")
      time.sleep(3.2)
      os.system('clear')
      count()
    else:
      print("\nI'll take that as a no, so Bye Bye!")
count()